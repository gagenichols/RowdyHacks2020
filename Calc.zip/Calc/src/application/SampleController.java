package application;

import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.TextField;

public class SampleController implements EventHandler<ActionEvent>{
	
	
	char op;
	
	String one, two;
	double x, y, z;
	
	@FXML
	private TextField operator;
	
	@FXML
	private TextField first;
	
	@FXML
	private TextField second;
	
	@FXML
	private TextField answer;
	
	@FXML
	private Button calculate;
	
	@Override
	public void handle(ActionEvent event) {
		
		op = operator.getText().charAt(0);
		
		one = first.getText();
		x = Double.parseDouble(one);
		
		two = second.getText();
		y = Double.parseDouble(two);
		
		if(op == '-') {
			z = x - y;
		} else if(op == '+') {
			z = x + y;
			
		}  else if(op == '*') {
			z = x * y;
		}  else if(op == '/') {
			z = x / y;
		}
		
		answer.setText(""+z);
		
		
	}
	
}
