import java.util.*;


public class Hello {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Scanner scan = new Scanner (System.in);
		
		double answer = 0;
		
		while(true) {
		
			System.out.println();
			
			System.out.print("-,+,*,/ :    ");
			char operator = scan.next().charAt(0);
			
			//System.out.println(operator);
			
			System.out.print("Enter your first number: ");
			double first = scan.nextDouble();
			
			System.out.print("Enter your second number: ");
			double second = scan.nextDouble();
			
			
			if(operator == '-') {
				answer = first - second;
			} else if(operator == '+') {
				answer = first + second;
				
			}  else if(operator == '*') {
				answer = first * second;
			}  else if(operator == '/') {
				answer = first / second;
			}
			
			
			
			
			System.out.print("The answer is: " + answer);
			
			//System.out.print("Please enter a whole number value: ");
			//int x = scan.nextInt();
			
			// comment 
			
			/*
			 * comment 
			 * comment 2
			 * comment 3
			 * comment 4
			 * 
			 */
			
			/*
			 * int
			 * double
			 * String
			 * char
			 */
			
			// type name = value;
			
			/*
			 * 
			 * ==
			 * !=
			 * < 
			 * >
			 * <=
			 * >=
			 */
			
			/*
			if(x > 0) {
				System.out.println("You have entered a positive number!");
			} else if(x == 0) {
				System.out.println("You have entered a zero!");
			} else {
				System.out.println("You have entered a negative number!");
			}
			*/
			scan.close();  // it is good practice to close your scanner
		}

	}

}
