import java.util.*;

public class Random {

	public static void main(String[] args) {
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a max value: ");
		int max = scan.nextInt();
		
		System.out.print("Enter a min value: ");
		int min = scan.nextInt();
		
		// int name_var = (int) (Math.random() * (max - min + 1) + min);
		
		int random_int = (int) (Math.random() * (max - min + 1) + min);
		
		System.out.println("Random value: " + random_int);

	}

}
