import java.util.*;

public class Array {

	public static void main(String[] args) {
		
		
		Scanner scan = new Scanner(System.in);
		
		System.out.print("Enter a string: ");
		String str = scan.nextLine();
		
		
		str = str.toUpperCase();
		str = str.replaceAll(" ", "");
		
		
		
		
		char[] ch = new char[str.length()];
		
		for( int i = 0; i < str.length(); i++) {
			ch[i] = str.charAt(i);
		}
		
		Arrays.sort(ch);
		
		System.out.println(Arrays.toString(ch));
		
		
		/*
		/*
		 * A collection of like type variables
		 * int, char, double, String...
		 * can be declared 2 ways
		 * 
		 * type name[]
		 * or 
		 * type[] name
		 */
		
		//int[] arrayInts;
		
		//arrayInts = new int[3];
		
		// int x =1, y=2, z=3;
		
		// start at 0
		/*
		arrayInts[0] = x;
		arrayInts[1] = y;
		arrayInts[2] = z;
		*/
		// arrayInts[3] = x;
		
		
		// [ 1, 2, 3 ]
		
		//System.out.println(Arrays.toString(arrayInts));
		/*
		int[] arr = new int[3];
		
		int i;
		int num = 5;
		
		for(i = 0; i < arr.length; i++) {
			arr[i] = num;
			num *= 2;
		}
		
		System.out.println(Arrays.toString(arr));
	 */
		
		scan.close();
	}

}
